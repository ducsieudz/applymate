# Applymate · Capstone BA

Trang web tĩnh (HTML + ảnh), không cần cài đặt hay build.

- Mở thử trên máy: bấm đúp `index.html`.
- Deploy Vercel: Framework Preset = **Other**, Build Command để trống, Output Directory = `.` (thư mục gốc).

BA: Nguyễn Thị Ngọc Ánh
